#' Simulation function for dependent censoring
#'
#' This function takes input as the distribution of survival & censoring data, 
#' the copula family and simulates the given number of data for y
#'
#' @param tauTC: kendall's tau value between T and C 
#' @param fam: copula family -- "frank" or "gauss" or "clayton" or "gumbel"  
#' @param dist.T: specify the distribution of T (survival time) -- "weibull" or "lnorm"
#' @param dist.C: specify the distribution of C (censoring time) -- "weibull" or "lnorm"
#' @param par.T: parameters of T
#' @param par.C: parameters of C
#' @param rot: rotation parameter
#' @param n: number of simulations
#' @param x: covariates or explanatory variables
#' @return estimates of x and y
#' @import dplyr
#' @import rafalib
#' @import rvinecopulib
#' @import tidyverse
#' @import fitdistrplus
#' @export
sim.TC<-function(tauTC=.5,fam="frank",dist.T=c("lnorm","weibull"),dist.C=c("lnorm","weibull"),
                par.T=c(1,1),par.C=c(1,1),beta.T = c(0.5,0.5),beta.C = c(0.5,0.5),X.T = X.T,X.C=X.C,rot=0,n=10)
{
  parTC<-ktau_to_par(fam,tauTC)
  u.TC<-rbicop(n,fam,rot, parTC)
  f.TC<-rep(0,n)
  F.TC<-rep(0,n)
  hC.condT<-rep(0,n)
  hT.condC<-rep(0,n)
  if(c(missing(beta.T))){
    if(dist.T=="lnorm"&&dist.C=="lnorm"){
      xT<-qlnorm(u.TC[,1],meanlog=par.T[1],sdlog=par.T[2])
      xC<-qlnorm(u.TC[,2],meanlog=par.C[1],sdlog=par.C[2])
    }  else if (dist.T=="weibull"&&dist.T=="weibull"){
      xC<-qweibull(u.TC[,2],shape=par.T[1],scale=par.T[2])
      xT<-qweibull(u.TC[,1],shape=par.C[1],scale=par.C[2])
    }
    delta<-as.numeric(xT<=xC)
    y<-pmin(xT,xC)
    if(dist.T=="lnorm"&&dist.C=="lnorm"){
    fT.y<-dlnorm(y,meanlog=par.T[1],sdlog=par.T[2])
    FT.y<-plnorm(y,meanlog=par.T[1],sdlog=par.T[2])
    fC.y<-dlnorm(y,meanlog=par.C[1],sdlog=par.C[2])
    FC.y<-plnorm(y,meanlog=par.C[1],sdlog=par.C[2])
    }  else if (dist.T=="weibull"&&dist.T=="weibull"){
      fT.y<-dweibull(y,shape=par.T[1],scale=par.T[2])
      FT.y<-pweibull(y,shape=par.T[1],scale=par.T[2])
      fC.y<-dweibull(y,shape=par.C[1],scale=par.C[2])
      FC.y<-pweibull(y,shape=par.C[1],scale=par.C[2])
    }
    u.TC.y<-cbind(FT.y,FC.y)
    f.TC.y<-dbicop(u.TC.y,fam,rot, parTC)*fT.y*fC.y
    F.TC.y<-pbicop(u.TC.y,fam,rot, parTC)
    hC.condT.y<-hbicop(u.TC.y, 1,fam,rot,parTC)
    hT.condC.y<-hbicop(u.TC.y, 2,fam,rot,parTC)
    list(tauTC=tauTC,fam=fam,dist.T=dist.T,dist.C=dist.C,
         par.T=par.T,par.C=par.C,rot=rot,n=n,xT=xT,xC=xC,u.TC=u.TC,
         delta=delta,y=y,fT.y=fT.y,FT.y=FT.y,FC.y=FC.y,fC.y=fC.y,f.TC.y=f.TC.y,F.TC.y=F.TC.y,
         hC.condT.y=hC.condT.y,hT.condC.y=hT.condC.y)
   } else {
     mu.T = X.T%*%beta.T
     mu.C = X.C%*%beta.C
     lam.T = par.T[2]*exp(X.T%*%beta.T)
     lam.C = par.C[2]*exp(X.C%*%beta.C)
     a.T = par.T[1]
     a.C = par.C[1]
     scale.T = (1/lam.T)^(1/a.T)
     scale.C = (1/lam.C)^(1/a.C)
     if(dist.T=="lnorm"&&dist.C=="lnorm"){
       xT<-qlnorm(u.TC[,1],meanlog=mu.T,sdlog=par.T)
       xC<-qlnorm(u.TC[,2],meanlog=mu.C,sdlog=par.C)
     } else if (dist.T=="weibull"&&dist.T=="weibull"){
       xC<-qweibull(u.TC[,2],shape=a.C,scale=scale.C)
       xT<-qweibull(u.TC[,1],shape=a.T,scale=scale.T)
     }
     delta<-as.numeric(xT<=xC)
     y<-pmin(xT,xC)
     if(dist.T=="lnorm"&&dist.C=="lnorm"){
       fT.y<-dlnorm(y,meanlog=mu.T,sdlog=par.T)
       FT.y<-plnorm(y,meanlog=mu.T,sdlog=par.T)
       fC.y<-dlnorm(y,meanlog=mu.C,sdlog=par.C)
       FC.y<-plnorm(y,meanlog=mu.C,sdlog=par.C)
     } else if (dist.T=="weibull"&&dist.T=="weibull"){
       fT.y<-dweibull(y,shape=a.T,scale=scale.T)
       FT.y<-pweibull(y,shape=a.T,scale=scale.T)
       fC.y<-dweibull(y,shape=a.C,scale=scale.C)
       FC.y<-pweibull(y,shape=a.C,scale=scale.C)
     }
       u.TC.y<-cbind(FT.y,FC.y)
       f.TC.y<-dbicop(u.TC.y,fam,rot, parTC)*fT.y*fC.y
       F.TC.y<-pbicop(u.TC.y,fam,rot, parTC)
       hC.condT.y<-hbicop(u.TC.y, 1,fam,rot,parTC)
       hT.condC.y<-hbicop(u.TC.y, 2,fam,rot,parTC)
       list(tauTC=tauTC,fam=fam,dist.T=dist.T,dist.C=dist.C,
            par.T=par.T,par.C=par.C,rot=rot,n=n,xT=xT,xC=xC,u.TC=u.TC,
            delta=delta,y=y,fT.y=fT.y,FT.y=FT.y,FC.y=FC.y,fC.y=fC.y,f.TC.y=f.TC.y,F.TC.y=F.TC.y,
            hC.condT.y=hC.condT.y,hT.condC.y=hT.condC.y)
     }
     
   }


###############################################################
#' Distribution of T (Survival)and C (Censoring)
#'
#' This function takes input survival & censoring data and
#' distribution family of T and C and returns the estimates of the distribution
#' given.
#'
#' @param t: survival time 
#' @param c: censoring time 
#' @param T.fam: specify the distribution of T (survival time) -- "weibull" or "lnorm"
#' @param C.fam: specify the distribution of C (censoring time) -- "weibull" or "lnorm"
#' @return estimates of x and y
#' @import dplyr
#' @import rafalib
#' @import rvinecopulib
#' @import tidyverse
#' @import fitdistrplus
#' @export 
dist.TC<-function(t,c,T.fam=c("weibull","lnorm"),C.fam=c("weibull","lnorm")){
  #t <- as.numeric(unlist(df[x]))
  #c <- as.numeric(unlist(df[y]))
  #t<-lapply(t,as.numeric)
  #c<-lapply(c,as.numeric)
  if (T.fam=="weibull" && C.fam == "weibull" ) {
    fd_T <- fitdist(t, "weibull",method="mle",lower = c(0.5, 0.5))
    fd_C <- fitdist(c, "weibull",method="mle",lower = c(0.5, 0.5))
    
  } else if (T.fam=="weibull" && C.fam == "lnorm") {
    fd_T <- fitdist(t, "weibull",method="mle",lower = c(0.5, 0.5))
    fd_C <- fitdist(c, "lnorm",method="mle")
  } else if (T.fam=="lnorm" && C.fam == "weibull"){
    fd_T <- fitdist(t, "lnorm",method="mle")
    fd_C <- fitdist(c, "weibull",method="mle",lower = c(0.5, 0.5))
  } else if (T.fam=="lnorm" && C.fam == "lnorm") {
    fd_T <- fitdist(t, "lnorm",method="mle")
    fd_C <- fitdist(c, "lnorm",method="mle")
  } else {
    print("Check the T.fam and C.fam")
  }
  return(c(fd_T$estimate,fd_C$estimate))
}

####################################################################
trunc.double<-function(x,trunc.low=-600,trunc.up=700){
  x[x>trunc.up]<-trunc.up
  x[x<trunc.low]<-trunc.low
  x
}

##################################################################
#' Loglikelihood for independent copula
#'
#' This function takes input as log(parameters),dataframe, colnames of Y = min(T,C) &
#' delta and the distribution of T and C. This returns the loglikelihood for independent
#' copula.
#' 
#' @param lpara: starting values of log of parameters -- eg: c(par(T),par(C))
#' @param df: Dataframe
#' @param y: columnname of Y=min(T,C) in dataframe. eg: "survivaltimeinmonths"
#' @param delta: columnname of delta in dataframe. eg: "delta"
#' @param T.fam: specify the distribution of x (survival time) -- "weibull" or "lnorm"
#' @param C.fam: specify the distribution of y (censoring time) -- "weibull" or "lnorm"
#' @param x: covariates or explanatory variables
#' @return loglikelihood for independent copula with specified margins
#' @import dplyr
#' @import rafalib
#' @import rvinecopulib
#' @import tidyverse
#' @import fitdistrplus
#' @export
loglike.ind <- function(lpara=list(1,log(0.5),2,log(0.5),beta.T,beta.C),df=df,y,delta,T.fam=c("weibull","lnorm"),
                        C.fam=c("weibull","lnorm"), x){
  y <- as.numeric(unlist(df[y]))
  delta <- as.numeric(unlist(df[delta]))
  #y = select(df,y)
  #delta = select(df,delta)
  par.Tw=exp(trunc.double(lpara[1:2],trunc.low=-600,trunc.up=700))
  par.Cw=exp(trunc.double(lpara[3:4],trunc.low=-600,trunc.up=700))
  par.T = exp(lpara[1:2])
  par.C = exp(lpara[3:4])
  if(missing(x)){
    if (T.fam=="weibull" && C.fam == "weibull"){
      fT<-suppressWarnings(dweibull(y, shape=par.Tw[1], scale = par.Tw[2], log = FALSE))
      fC<-suppressWarnings(dweibull(y, shape=par.Cw[1], scale = par.Cw[2], log = FALSE))
      FT<-suppressWarnings(pweibull(y, shape=par.Tw[1], scale = par.Tw[2], log = FALSE))
      FC<-suppressWarnings(pweibull(y, shape=par.Cw[1], scale = par.Cw[2], log = FALSE))
    }else if (T.fam=="lnorm" && C.fam == "lnorm"){
      fT<-suppressWarnings(dlnorm(y, meanlog =par.T[1], sdlog =  par.T[2], log = FALSE))
      fC<-suppressWarnings(dlnorm(y,meanlog =par.C[1], sdlog =  par.C[2], log = FALSE))
      FT<-suppressWarnings(plnorm(y, meanlog =par.T[1], sdlog =  par.T[2], log = FALSE))
      FC<-suppressWarnings(plnorm(y, meanlog =par.C[1], sdlog =  par.C[2], log = FALSE))
    }
    
  } else {
    t = df[df$delta==1, ]
    X.T = as.matrix(subset(t,select=x))
    #T.1 = select(df[df$delta==1, ],x)
    #X.T = as.matrix(T.1)
    c = df[df$delta==0, ]
    X.C = as.matrix(subset(c,select=x))
    #C.1 = select(df[df$delta==0, ],x)
    #X.C = as.matrix(C.1)
    X.Tl = cbind(rep(1,dim(X.T)[1]),X.T)
    X.Cl = cbind(rep(1,dim(X.C)[1]),X.C)
    
    if (T.fam=="lnorm" && C.fam == "lnorm") {
      bet = as.numeric(lpara[3:length(lpara)])
      beta.T = as.matrix(bet[1:(length(bet)/2)],ncol=1)
      beta.C = as.matrix(bet[((length(bet)/2)+1):length(bet)],ncol=1)
      mu.T = X.Tl%*%beta.T
      mu.C = X.Cl%*%beta.C
      sig.T = lpara[1]
      sig.C = lpara[2]
      FT = suppressWarnings(plnorm(y,meanlog=mu.T,sdlog=exp(sig.T),log=FALSE))
      fT = suppressWarnings(dlnorm(y,meanlog=mu.T,sdlog=exp(sig.T),log=FALSE))
      FC = suppressWarnings(plnorm(y,meanlog=mu.C,sdlog=exp(sig.C),log=FALSE))
      fC = suppressWarnings(dlnorm(y,meanlog=mu.C,sdlog=exp(sig.C),log=FALSE))
    } else if (T.fam=="weibull" && C.fam == "weibull" ){
      bet = as.numeric(lpara[5:length(lpara)])
      beta.T = as.matrix(bet[1:(length(bet)/2)],ncol=1)
      beta.C = as.matrix(bet[((length(bet)/2)+1):length(bet)],ncol=1)
      lam.T = par.Tw[2]*exp(X.T%*%beta.T)
      lam.C = par.Cw[2]*exp(X.C%*%beta.C)
      a.T = par.Tw[1]
      a.C = par.Cw[1]
      scale.T = (1/lam.T)^(1/a.T)
      scale.C = (1/lam.C)^(1/a.C)
      fT<-suppressWarnings(dweibull(y, shape=par.Tw[1], scale = scale.T, log = FALSE))
      fC<-suppressWarnings(dweibull(y, shape=par.Cw[1], scale = scale.C, log = FALSE))
      FT<-suppressWarnings(pweibull(y, shape=par.Tw[1], scale = scale.T, log = FALSE))
      FC<-suppressWarnings(pweibull(y, shape=par.Cw[1], scale = scale.C, log = FALSE)) 
    }
  }
  l1w<-sum(log(fT[delta==1]*(1-FC[delta==1])))
  l0w<-sum(log(fC[delta==0]*(1-FT[delta==0])))
  l0w+l1w
}

####################################################################3
#' Loglikelihood for dependent copula
#'
#' This function takes input as log(parameters),dataframe, colnames of Y = min(T,C) &
#' delta and the distribution of T and C. This returns the loglikelihood for dependent
#' copula.
#' 
#' @param lpara: starting values of log(parameters) -- eg: c(par(T),par(C),par(copula))
#' @param df: Dataframe
#' @param y: columnname of Y=min(T,C) in dataframe. eg: "survivaltimeinmonths"
#' @param delta: columnname of delta in dataframe. eg: "delta"
#' @param T.fam: specify the distribution of x (survival time) -- "weibull" or "lnorm"
#' @param C.fam: specify the distribution of y (censoring time) -- "weibull" or "lnorm"
#' @param Cop.fam: specify the copula family -- "frank","clayton","gumbel","gauss"
#' @param x: covariates or explanatory variables
#' @return loglikelihood for dependent copula with specified margins
#' @import dplyr
#' @import rafalib
#' @import rvinecopulib
#' @import tidyverse
#' @import fitdistrplus
#' @export
loglike.dep<-function(lpara=c(1,log(0.5),2,log(0.5),tau,beta.T,beta.C),Cop.fam = "frank",df=df,y,delta,T.fam=c("weibull","lnorm"),
                      C.fam=c("weibull","lnorm"), x){
  y <- as.numeric(unlist(df[y]))
  delta <- as.numeric(unlist(df[delta]))
  #y = select(df,y)
  #delta = select(df,delta)
  par.Tl = exp(lpara[2:3])
  par.Cl = exp(lpara[4:5])
  if (Cop.fam=="frank"){
    par.Tw=exp(trunc.double(lpara[2:3],trunc.low=-15,trunc.up=15))
    par.Cw=exp(trunc.double(lpara[4:5],trunc.low=-15,trunc.up=15)) 
    par.z=min(c(lpara[1],15))
    par.tau<-exp(par.z)/(1+exp(par.z))
    #print(paste("par.z",par.z,"par.tau",par.tau))
    par.cop<-sign(par.tau) * ktau_to_par("frank", max(1e-9, abs(par.tau)))
    #print(par.cop)
    par.cop<-min(34,par.cop)
    par.cop<-max(1e-5,par.cop)
    cop<-bicop_dist("frank",0,par.cop)
  } else if (Cop.fam=="gumbel"){
    par.Tw=exp(trunc.double(lpara[2:3],trunc.low=-150,trunc.up=150))
    par.Cw=exp(trunc.double(lpara[4:5],trunc.low=-150,trunc.up=150))
    par.z=min(c(lpara[1],150))
    par.tau<-exp(par.z)/(1+exp(par.z))
    par.cop<-sign(par.tau) * ktau_to_par("gumbel", max(1e-9, abs(par.tau)))
    par.cop<-min(50,par.cop)
    par.cop<-max(1,par.cop)
    cop<-bicop_dist("gumbel",0,par.cop)
  } else if (Cop.fam=="clayton"){
    par.Tw=exp(lpara[2:3])
    par.Cw=exp(lpara[4:5])
    par.z=min(c(lpara[1],700))
    par.tau<-exp(par.z)/(1+exp(par.z))
    par.cop<-sign(par.tau) * ktau_to_par("clayton", max(1e-9, abs(par.tau)))
    par.cop<-min(27,par.cop)
    par.cop<-max(1e-9,par.cop)
    cop<-bicop_dist("clayton",0,par.cop)
  } else {
    par.Tw=exp(lpara[2:3])
    par.Cw=exp(lpara[4:5])
    par.z=min(c(lpara[1],700))
    par.tau<-exp(par.z)/(1+exp(par.z))
    par.cop<-sign(par.tau) * ktau_to_par("gauss", max(1e-9, abs(par.tau)))
    #print(par.cop)
    par.cop<-min(1,par.cop)
    par.cop<-max(1e-9,par.cop)
    cop<-bicop_dist("gauss",0,par.cop)
  }
  n=length(y)
  if(missing(x)){
    if (T.fam=="weibull" && C.fam == "weibull" ){
      fT<-suppressWarnings(dweibull(y, shape=par.Tw[1], scale = par.Tw[2], log = FALSE))
      fC<-suppressWarnings(dweibull(y, shape=par.Cw[1], scale = par.Cw[2], log = FALSE))
      FT<-suppressWarnings(pweibull(y, shape=par.Tw[1], scale = par.Tw[2], log = FALSE))
      FC<-suppressWarnings(pweibull(y, shape=par.Cw[1], scale = par.Cw[2], log = FALSE))
    } else if (T.fam=="lnorm" && C.fam == "lnorm"){
      fT<-suppressWarnings(dlnorm(y, meanlog =par.Tl[1], sdlog =  par.Tl[2], log = FALSE))
      fC<-suppressWarnings(dlnorm(y,meanlog =par.Cl[1], sdlog =  par.Cl[2], log = FALSE))
      FT<-suppressWarnings(plnorm(y, meanlog =par.Tl[1], sdlog =  par.Tl[2], log = FALSE))
      FC<-suppressWarnings(plnorm(y, meanlog =par.Cl[1], sdlog =  par.Cl[2], log = FALSE))
    }
  } else {
    t = df[df$delta==1, ]
    X.T = as.matrix(subset(t,select=x))
    #T.1 = select(df[df$delta==1, ],x)
    #X.T = as.matrix(T.1)
    c = df[df$delta==0, ]
    X.C = as.matrix(subset(c,select=x))
    #C.1 = select(df[df$delta==0, ],x)
    #X.C = as.matrix(C.1)
    X.Tl = cbind(rep(1,dim(X.T)[1]),X.T)
    X.Cl = cbind(rep(1,dim(X.C)[1]),X.C)
    if (T.fam=="lnorm" && C.fam == "lnorm") {
      bet = as.numeric(lpara[4:length(lpara)])
      beta.T = as.matrix(bet[1:(length(bet)/2)],ncol=1)
      beta.C = as.matrix(bet[((length(bet)/2)+1):length(bet)],ncol=1)
      mu.T = X.Tl%*%beta.T
      mu.C = X.Cl%*%beta.C
      sig.T = lpara[2]
      sig.C = lpara[3]
      FT = suppressWarnings(plnorm(y,meanlog=mu.T,sdlog=exp(sig.T),log=FALSE))
      fT = suppressWarnings(dlnorm(y,meanlog=mu.T,sdlog=exp(sig.T),log=FALSE))
      FC = suppressWarnings(plnorm(y,meanlog=mu.C,sdlog=exp(sig.C),log=FALSE))
      fC = suppressWarnings(dlnorm(y,meanlog=mu.C,sdlog=exp(sig.C),log=FALSE))
    } else if (T.fam=="weibull" && C.fam == "weibull" ){
      bet = as.numeric(lpara[6:length(lpara)])
      beta.T = as.matrix(bet[1:(length(bet)/2)],ncol=1)
      beta.C = as.matrix(bet[((length(bet)/2)+1):length(bet)],ncol=1)
      lam.T = par.Tw[2]*exp(X.T%*%beta.T)
      lam.C = par.Cw[2]*exp(X.C%*%beta.C)
      a.T = par.Tw[1]
      a.C = par.Cw[1]
      scale.T = (1/lam.T)^(1/a.T)
      scale.C = (1/lam.C)^(1/a.C)
      fT<-suppressWarnings(dweibull(y, shape=par.Tw[1], scale = scale.T, log = FALSE))
      fC<-suppressWarnings(dweibull(y, shape=par.Cw[1], scale = scale.C, log = FALSE))
      FT<-suppressWarnings(pweibull(y, shape=par.Tw[1], scale = scale.T, log = FALSE))
      FC<-suppressWarnings(pweibull(y, shape=par.Cw[1], scale = scale.C, log = FALSE)) 
    }
  }
  hC.condT<-hbicop(cbind(FT,FC), 1,cop)
  hT.condC<-hbicop(cbind(FT,FC), 2,cop)
  l1<-sum(log(fT[delta==1])+log(1-hC.condT[delta==1]))
  l0<-sum(log(fC[delta==0])+log(1-hT.condC[delta==0]))
  l1+l0
}
##################################################################
#' P(T<=C)
#'
#' This function takes input as parameters,copula family and the distribution of T and C 
#' This returns the integrand for T<=C
#' 
#' @param par.cop: copula parameters
#' @param par.C: parameters of Censoring C
#' @param par.T: parameters of Survival T
#' @param y: columnname of delta in dataframe. eg: "delta"
#' @param T.fam: specify the distribution of x (survival time) -- "weibull" or "lnorm"
#' @param C.fam: specify the distribution of y (censoring time) -- "weibull" or "lnorm"
#' @param Cop.fam: specify the copula family -- "frank","clayton","gumbel","gauss"
#' @param x: covariates or explanatory variables
#' @return integrand for T<=C
#' @import dplyr
#' @import rafalib
#' @import rvinecopulib
#' @import tidyverse
#' @import fitdistrplus
#' @export
integrand.T.leq.C<-function(par,par.cop,par.C,par.T,beta.T,beta.C,Cop.fam="frank",C.fam=c("weibull","lnorm")
                            ,T.fam=c("weibull","lnorm"),x=c(age,gender)){
  uc<-par
  if(missing(x)){
    if (T.fam=="weibull"&& C.fam=="weibull"){
      Fc.inv<-qweibull(uc, shape=exp(par.C[1]), scale = exp(par.C[2]), log = FALSE)
      temp<-pweibull(Fc.inv,shape=exp(par.T[1]), scale = exp(par.T[2]), log = FALSE)
    } else if (T.fam=="lnorm"&& C.fam=="lnorm"){
      Fc.inv<-qlnorm(uc,meanlog=par.C[1],sdlog=exp(par.C[2]))
      temp<-plnorm(Fc.inv,meanlog=par.T[1],sdlog=exp(par.T[2]))
    }
    if(Cop.fam=="gumbel"){par.cop<-min(50,par.cop)}
    fam_cop<-bicop_dist(Cop.fam,0,par.cop)
  } else{
      if (T.fam=="weibull"&& C.fam=="weibull"){
      gamma.T = exp(par.T[1])
      lambda.T = exp(par.T[2])
      gamma.C = exp(par.C[1])
      lambda.C = exp(par.C[2])
      #lc.T = c()
      #lc.C = c()
      for (i in 1:length(x)){
        temp.T[i] = x[i]*beta.T[i]
        temp.C[i] = x[i]*beta.C[i]
      }
      lam.T = sum(temp.T)
      lam.C = sum(temp.C)
      #a.T = par.T[1]
      #a.C = par.C[1]
      scale.T = (1/lam.T)^(1/gamma.T)
      scale.C = (1/lam.C)^(1/gamma.C)
      Fc.inv<-qweibull(uc, shape=gamma.C, scale = scale.C, log = FALSE)
      #Fc.inv<-qlnorm(uc,meanlog=par.C[1],sdlog=par.C[2])
      #temp<-plnorm(Fc.inv,meanlog=par.T[1],sdlog=par.T[2])
      temp<-pweibull(Fc.inv,shape=gamma.T, scale = scale.T, log = FALSE)
    } else if (T.fam=="lnorm" && C.fam == "lnorm") {
      sig.T = exp(par.T[1])
      sig.C = exp(par.C[1])
      for (i in 1:length(x)){
        temp.T[i] = x[i]*beta.T[i]
        temp.C[i] = x[i]*beta.C[i]
      }
      mu.T = sum(temp.T)
      mu.C = sum(temp.C)
      Fc.inv<-qlnorm(uc,meanlog=mu.C,sdlog=sig.C)
      temp<-plnorm(Fc.inv,meanlog=mu.T,sdlog=sig.T)
    }
  }
  if(Cop.fam=="gumbel"){par.cop<-min(50,par.cop)}
  fam_cop<-bicop_dist(Cop.fam,0,par.cop)
  hT.condC<-hbicop(cbind(temp,uc),2,fam_cop)
  hT.condC
}

###########################################################
#' Bootstrapping
#' 
#' @param startpar: starting values of parameters -- eg: c(par(T),par(C),par(copula))
#' @param dfb: dataframe
#' @param yb: columnname of Y=min(T,C) in dataframe. eg: "survivaltimeinmonths"
#' @param deltab: columnname of delta in dataframe. eg: "delta"
#' @param Tfam: specify the distribution of x (survival time) -- "weibull" or "lnorm"
#' @param Cfam: specify the distribution of y (censoring time) -- "weibull" or "lnorm"
#' @param Copfam: specify the copula family -- "frank","clayton","gumbel","gauss"
#' @param B: number of bootstraps
#' @param x: covariates or explanatory variables
#' @return bootstrapping result
#' @import dplyr
#' @import rafalib
#' @import rvinecopulib
#' @import tidyverse
#' @import fitdistrplus
#' @export
boot.TC <- function(dfb,yb,deltab,Copfam,startpar,B,
                    Tfam,Cfam,xb){
  y1 <- as.numeric(unlist(dfb[yb]))
  delta1 <- as.numeric(unlist(dfb[deltab]))
  n<-length(y1)
  Xb = as.matrix(subset(dfb,select=xb))
  out.mat<-matrix(0,B,length(startpar)+4)
  for(i in 1:B){
    ind.b<-sample(1:n,n,replace=TRUE)
    y.b<-y1[ind.b]
    delta.b<-delta1[ind.b]
    if(missing(xb)){dt<-data.frame(y.b,delta.b)}
    X.b<-Xb[ind.b,]
    dt<-data.frame(y.b,delta.b,X.b)
    if(Copfam=="frank"){
      if (Tfam=="weibull"&& Cfam=="weibull"){
        out.b<-optim(startpar,fn=loglike.dep, Cop.fam = "frank",df = dt,y="y.b",delta="delta.b",T.fam="weibull",C.fam="weibull",
                     x="X.b",control=list(trace=0,fnscale=-1),method="BFGS")
        #print(out.b$par[5])
        out.b$tau<-exp(out.b$par[1])/(1+exp(out.b$par[1]))
        names(out.b$tau)<-"tau"
        out.b$cop.par<-sign(out.b$tau) * ktau_to_par(Copfam, max(1e-20, abs(out.b$tau)))
        out.mat[i,]<-c(out.b$par,out.b$cop.par,out.b$tau,
                       out.b$value,out.b$convergence)
      } else if (Tfam=="weibull"&& Cfam=="lnorm"){
        out.b<-optim(startpar,loglike.dep,Cop.fam = "frank",T.fam="weibull",C.fam="lnorm",
                     y="y.b",delta="delta.b",df=dt,x="X.b",
                     control=list(trace=0,fnscale=-1),method="BFGS")
        #print(out.b$par[5])
        out.b$tau<-exp(out.b$par[1])/(1+exp(out.b$par[1]))
        names(out.b$tau)<-"tau"
        out.b$cop.par<-sign(out.b$tau) * ktau_to_par(Copfam, max(1e-20, abs(out.b$tau)))
        out.mat[i,]<-c(out.b$par,out.b$cop.par,out.b$tau,
                       out.b$value,out.b$convergence)
      } else if (Tfam=="lnorm"&& Cfam=="weibull"){
        out.b<-optim(startpar,loglike.dep,Cop.fam = "frank",T.fam="lnorm",C.fam="weibull",
                     y="y.b",delta="delta.b",df=dt,x="X.b",
                     control=list(trace=0,fnscale=-1),method="BFGS")
        #print(out.b$par[5])
        out.b$tau<-exp(out.b$par[1])/(1+exp(out.b$par[1]))
        names(out.b$tau)<-"tau"
        out.b$cop.par<-sign(out.b$tau) * ktau_to_par(Copfam, max(1e-20, abs(out.b$tau)))
        out.mat[i,]<-c(out.b$par,out.b$cop.par,out.b$tau,
                       out.b$value,out.b$convergence)
      } else if (Tfam=="lnorm"&& Cfam=="lnorm"){
        out.b<-optim(startpar,loglike.dep,Cop.fam = "frank",T.fam="lnorm",C.fam="lnorm",
                     y="y.b",delta="delta.b",df=dt,x="X.b",
                     control=list(trace=0,fnscale=-1),method="BFGS")
        #print(out.b$par[5])
        out.b$tau<-exp(out.b$par[1])/(1+exp(out.b$par[1]))
        names(out.b$tau)<-"tau"
        out.b$cop.par<-sign(out.b$tau) * ktau_to_par(Copfam, max(1e-20, abs(out.b$tau)))
        out.mat[i,]<-c(out.b$par,out.b$cop.par,out.b$tau,
                       out.b$value,out.b$convergence)
      }
      
    } else if (Copfam=="ind"){ 
      if (Tfam=="weibull"&& Cfam=="lnorm"){
        out.b<-optim(startpar,loglike.ind,T.fam="weibull",C.fam="lnorm",y="y.b",delta="delta.b",df=dt,x="X.b",
                     control=list(trace=0,fnscale=-1),method="BFGS")
        out.b$tau<-0
        names(out.b$tau)<-"tau"
        out.b$cop.par<-0
        out.mat[i,]<-c(out.b$par,.5,out.b$cop.par,out.b$tau,
                       out.b$value,out.b$convergence)
      } else if (Tfam=="weibull"&& Cfam=="weibull") {
        out.b<-optim(startpar,loglike.ind,T.fam="weibull",C.fam="weibull",y="y.b",delta="delta.b",df=dt,x="X.b",
                     control=list(trace=0,fnscale=-1),method="BFGS")
        out.b$tau<-0
        names(out.b$tau)<-"tau"
        out.b$cop.par<-0
        out.mat[i,]<-c(out.b$par,.5,out.b$cop.par,out.b$tau,
                       out.b$value,out.b$convergence)
        
      } else if (Tfam=="lnorm"&& Cfam=="weibull"){
        out.b<-optim(startpar,loglike.ind,T.fam="lnorm",C.fam="weibull",y="y.b",delta="delta.b",df=dt,x="X.b",
                     control=list(trace=0,fnscale=-1),method="BFGS")
        out.b$tau<-0
        names(out.b$tau)<-"tau"
        out.b$cop.par<-0
        out.mat[i,]<-c(out.b$par,.5,out.b$cop.par,out.b$tau,
                       out.b$value,out.b$convergence)
      } else if (Tfam=="lnorm"&& Cfam=="lnorm"){
        out.b<-optim(startpar,loglike.ind,T.fam="lnorm",C.fam="lnorm",y="y.b",delta="delta.b",df=dt,x="X.b",
                     control=list(trace=0,fnscale=-1),method="BFGS")
        out.b$tau<-0
        names(out.b$tau)<-"tau"
        out.b$cop.par<-0
        out.mat[i,]<-c(out.b$par,.5,out.b$cop.par,out.b$tau,
                       out.b$value,out.b$convergence)
      }
      
      
    } else if (Copfam=="clayton") {
      if (Tfam=="weibull"&& Cfam=="lnorm"){
        out.b<-optim(startpar,loglike.dep,Cop.fam="clayton",T.fam="weibull",C.fam="lnorm",
                     y="y.b",delta="delta.b",df=dt,x="X.b",
                     control=list(trace=0,fnscale=-1),method="BFGS")
        out.b$tau<-exp(out.b$par[1])/(1+exp(out.b$par[1]))
        names(out.b$tau)<-"tau"
        out.b$cop.par<-sign(out.b$tau) * ktau_to_par(Copfam, max(1e-9,
                                                              abs(out.b$tau)))
        out.mat[i,]<-c(out.b$par,out.b$cop.par,out.b$tau,out.b$value,
                       out.b$convergence)
      } else if (Tfam=="weibull"&& Cfam=="weibull"){
        out.b<-optim(startpar,loglike.dep,Cop.fam="clayton",T.fam="weibull",C.fam="weibull",
                     y="y.b",delta="delta.b",df=dt,x="X.b",
                     control=list(trace=0,fnscale=-1),method="BFGS")
        out.b$tau<-exp(out.b$par[1])/(1+exp(out.b$par[1]))
        names(out.b$tau)<-"tau"
        out.b$cop.par<-sign(out.b$tau) * ktau_to_par(Copfam, max(1e-9,
                                                              abs(out.b$tau)))
        out.mat[i,]<-c(out.b$par,out.b$cop.par,out.b$tau,out.b$value,
                       out.b$convergence)
      } else if (Tfam=="lnorm"&& Cfam=="weibull"){
        out.b<-optim(startpar,loglike.dep,Cop.fam="clayton",T.fam="lnorm",C.fam="weibull",
                     y="y.b",delta="delta.b",df=dt,x="X.b",
                     control=list(trace=0,fnscale=-1),method="BFGS")
        out.b$tau<-exp(out.b$par[1])/(1+exp(out.b$par[1]))
        names(out.b$tau)<-"tau"
        out.b$cop.par<-sign(out.b$tau) * ktau_to_par(Copfam, max(1e-9,
                                                              abs(out.b$tau)))
        out.mat[i,]<-c(out.b$par,out.b$cop.par,out.b$tau,out.b$value,
                       out.b$convergence)
      } else if (Tfam=="lnorm"&& Cfam=="lnorm"){
        out.b<-optim(startpar,loglike.dep,Cop.fam="clayton",T.fam="lnorm",C.fam="lnorm",
                     y="y.b",delta="delta.b",df=dt,x="X.b",
                     control=list(trace=0,fnscale=-1),method="BFGS")
        out.b$tau<-exp(out.b$par[1])/(1+exp(out.b$par[1]))
        names(out.b$tau)<-"tau"
        out.b$cop.par<-sign(out.b$tau) * ktau_to_par(Copfam, max(1e-9,
                                                              abs(out.b$tau)))
        out.mat[i,]<-c(out.b$par,out.b$cop.par,out.b$tau,out.b$value,
                       out.b$convergence)
      }
    } else if (Copfam=="gumbel"){
      if (Tfam=="weibull"&& Cfam=="weibull"){
        out.b<-optim(startpar,loglike.dep,Cop.fam="gumbel",T.fam="weibull",C.fam="weibull",
                     y="y.b",delta="delta.b",df=dt,x="X.b",
                     control=list(trace=0,fnscale=-1),method="BFGS")
        out.b$tau<-exp(out.b$par[1])/(1+exp(out.b$par[1]))
        names(out.b$tau)<-"tau"
        out.b$cop.par<-sign(out.b$tau) * ktau_to_par(Copfam, max(1e-9,
                                                              abs(out.b$tau)))
        out.mat[i,]<-c(out.b$par,out.b$cop.par,out.b$tau,out.b$value,
                       out.b$convergence)
      } else if (Tfam=="weibull"&& Cfam=="lnorm"){
        out.b<-optim(startpar,loglike.dep,Cop.fam="gumbel",T.fam="weibull",C.fam="lnorm",
                     y="y.b",delta="delta.b",df=dt,x="X.b",
                     control=list(trace=0,fnscale=-1),method="BFGS")
        out.b$tau<-exp(out.b$par[1])/(1+exp(out.b$par[1]))
        names(out.b$tau)<-"tau"
        out.b$cop.par<-sign(out.b$tau) * ktau_to_par(Copfam, max(1e-9,
                                                              abs(out.b$tau)))
        out.mat[i,]<-c(out.b$par,out.b$cop.par,out.b$tau,out.b$value,
                       out.b$convergence)
      } else if (Tfam=="lnorm"&& Cfam=="weibull"){
        out.b<-optim(startpar,loglike.dep,Cop.fam="gumbel",T.fam="lnorm",C.fam="weibull",
                     y="y.b",delta="delta.b",df=dt,x="X.b",
                     control=list(trace=0,fnscale=-1),method="BFGS")
        out.b$tau<-exp(out.b$par[1])/(1+exp(out.b$par[1]))
        names(out.b$tau)<-"tau"
        out.b$cop.par<-sign(out.b$tau) * ktau_to_par(Copfam, max(1e-9,
                                                              abs(out.b$tau)))
        out.mat[i,]<-c(out.b$par,out.b$cop.par,out.b$tau,out.b$value,
                       out.b$convergence)
      } else if (Tfam=="lnorm"&& Cfam=="lnorm"){
        out.b<-optim(startpar,loglike.dep,Cop.fam="gumbel",T.fam="lnorm",C.fam="lnorm",
                     y="y.b",delta="delta.b",df=dt,x="X.b",
                     control=list(trace=0,fnscale=-1),method="BFGS")
        out.b$tau<-exp(out.b$par[1])/(1+exp(out.b$par[1]))
        names(out.b$tau)<-"tau"
        out.b$cop.par<-sign(out.b$tau) * ktau_to_par(Copfam, max(1e-9,
                                                              abs(out.b$tau)))
        out.mat[i,]<-c(out.b$par,out.b$cop.par,out.b$tau,out.b$value,
                       out.b$convergence)
      }
    } else if (Copfam=="gauss"){
      if (Tfam=="lnorm"&& Cfam=="lnorm"){
        out.b<-optim(startpar,loglike.dep,Cop.fam="gauss",T.fam="lnorm",C.fam="lnorm",
                     y="y.b",delta="delta.b",df=dt,x="X.b",
                     control=list(trace=0,fnscale=-1),method="BFGS")
        out.b$tau<-exp(out.b$par[1])/(1+exp(out.b$par[1]))
        names(out.b$tau)<-"tau"
        out.b$cop.par<-sign(out.b$tau) * ktau_to_par(Copfam, max(1e-9,
                                                              abs(out.b$tau)))
        out.mat[i,]<-c(out.b$par,out.b$cop.par,out.b$tau,out.b$value,
                       out.b$convergence)
      } else if(Tfam=="lnorm"&& Cfam=="weibull"){
        out.b<-optim(startpar,loglike.dep,Cop.fam="gauss",T.fam="lnorm",C.fam="weibull",
                     y="y.b",delta="delta.b",df=dt,x="X.b",
                     control=list(trace=0,fnscale=-1),method="BFGS")
        out.b$tau<-exp(out.b$par[1])/(1+exp(out.b$par[1]))
        names(out.b$tau)<-"tau"
        out.b$cop.par<-sign(out.b$tau) * ktau_to_par(Copfam, max(1e-9,
                                                              abs(out.b$tau)))
        out.mat[i,]<-c(out.b$par,out.b$cop.par,out.b$tau,out.b$value,
                       out.b$convergence)
      } else if (Tfam=="weibull"&& Cfam=="lnorm"){
        out.b<-optim(startpar,loglike.dep,Cop.fam="gauss",T.fam="weibull",C.fam="lnorm",
                     y="y.b",delta="delta.b",df=dt,x="X.b",
                     control=list(trace=0,fnscale=-1),method="BFGS")
        out.b$tau<-exp(out.b$par[1])/(1+exp(out.b$par[1]))
        names(out.b$tau)<-"tau"
        out.b$cop.par<-sign(out.b$tau) * ktau_to_par(Copfam, max(1e-9,
                                                              abs(out.b$tau)))
        out.mat[i,]<-c(out.b$par,out.b$cop.par,out.b$tau,out.b$value,
                       out.b$convergence)
      } else if (Tfam=="weibull"&& Cfam=="weibull"){
        out.b<-optim(startpar,loglike.dep,Cop.fam="gauss",T.fam="weibull",C.fam="weibull",
                     y="y.b",delta="delta.b",df=dt,x="X.b",
                     control=list(trace=0,fnscale=-1),method="BFGS")
        out.b$tau<-exp(out.b$par[1])/(1+exp(out.b$par[1]))
        names(out.b$tau)<-"tau"
        out.b$cop.par<-sign(out.b$tau) * ktau_to_par(Copfam, max(1e-9,
                                                              abs(out.b$tau)))
        out.mat[i,]<-c(out.b$par,out.b$cop.par,out.b$tau,out.b$value,
                       out.b$convergence)
      }
      
    }
    
    
  }
  
  #colnames(out.mat)<-c("meanlogT","log(sdlogT)","meanlogC","log(sdlogC)","logit",
                       #"cop.par","tau","loglike","conv")
  return(out.mat)
  
}
